#!/usr/bin/env python3
"""
Simple Separated HUD - Just adds HUD without breaking anything
"""

import pygame
import math
import random

class SimpleSeparatedHUD:
    def __init__(self, screen_width: int, screen_height: int):
        self.screen_width = screen_width
        self.screen_height = screen_height
        
        # Simple separation - just reserve space at bottom
        self.hud_height = 100
        self.separator_height = 4
        self.game_area_height = screen_height - self.hud_height - self.separator_height
        self.separator_y = self.game_area_height
        self.hud_start_y = self.separator_y + self.separator_height
        
        # Colors
        self.separator_color = (0, 255, 255)  # Cyan separator
        self.hud_bg_color = (15, 15, 30)
        self.text_color = (255, 255, 255)
        self.accent_color = (0, 255, 255)
        self.success_color = (100, 255, 150)
        self.warning_color = (255, 100, 100)
        self.timer_color = (255, 215, 0)
        self.fact_color = (180, 180, 255)
        
        # Fonts
        self.main_font = pygame.font.Font(None, 28)
        self.small_font = pygame.font.Font(None, 20)
        self.fact_font = pygame.font.Font(None, 18)
        
        # Animation
        self.pulse_phase = 0
        self.warning_flash = 0
        self.fact_timer = 0
        self.current_fact = 0
        
        # Simple facts
        self.facts = [
            "🌀 Hadamard gates create superposition states",
            "🔗 Entangled qubits affect each other instantly",
            "⚛️ Qubits hold infinite possible states",
            "🚪 CNOT gates create quantum entanglement",
            "📡 Quantum teleportation transfers information",
            "🌊 Superposition enables quantum parallelism",
            "🚫 No-Cloning: Can't copy quantum states",
            "🔐 Shor's algorithm breaks encryption fast",
            "🔍 Grover's algorithm searches in √N time",
            "💨 Decoherence destroys quantum properties"
        ]
    
    def get_game_area_height(self):
        return self.game_area_height
    
    def update(self, dt):
        self.pulse_phase += dt * 3
        self.warning_flash += dt * 8
        self.fact_timer += dt
        if self.fact_timer >= 5.0:
            self.fact_timer = 0
            self.current_fact = (self.current_fact + 1) % len(self.facts)
    
    def draw(self, screen, score, lives, level, qubits_collected, total_qubits, 
             entanglement_timer=0, superposition_timer=0, measurement_timer=0):
        
        # Draw separator
        pygame.draw.rect(screen, self.separator_color, 
                        (0, self.separator_y, self.screen_width, self.separator_height))
        
        # Draw HUD background
        pygame.draw.rect(screen, self.hud_bg_color, 
                        (0, self.hud_start_y, self.screen_width, self.hud_height))
        
        # Draw HUD content
        y = self.hud_start_y + 10
        
        # Score
        score_text = self.main_font.render(f"SCORE: {score:,}", True, self.text_color)
        screen.blit(score_text, (20, y))
        
        # Lives
        lives_text = self.main_font.render(f"LIVES: {lives}", True, self.text_color)
        screen.blit(lives_text, (180, y))
        
        # Level
        level_text = self.main_font.render(f"LEVEL: {level}", True, self.text_color)
        screen.blit(level_text, (280, y))
        
        # Qubits
        qubits_text = self.main_font.render(f"QUBITS: {qubits_collected}/{total_qubits}", True, self.text_color)
        screen.blit(qubits_text, (380, y))
        
        # Timers
        timer_x = 20
        timer_y = y + 30
        
        if entanglement_timer > 0:
            timer_text = self.small_font.render(f"ENTANGLE: {entanglement_timer:.1f}s", True, self.accent_color)
            screen.blit(timer_text, (timer_x, timer_y))
            timer_x += 120
        
        if superposition_timer > 0:
            timer_text = self.small_font.render(f"SUPERPOS: {superposition_timer:.1f}s", True, self.success_color)
            screen.blit(timer_text, (timer_x, timer_y))
            timer_x += 120
        
        if measurement_timer > 0:
            timer_text = self.small_font.render(f"MEASURE: {measurement_timer:.1f}s", True, self.timer_color)
            screen.blit(timer_text, (timer_x, timer_y))
        
        # Did you know fact
        fact_text = self.small_font.render("DID YOU KNOW?", True, self.accent_color)
        screen.blit(fact_text, (500, y))
        
        current_fact_text = self.facts[self.current_fact]
        fact_surface = self.fact_font.render(current_fact_text, True, self.fact_color)
        screen.blit(fact_surface, (500, y + 20))
    
    def draw_pause_overlay(self, screen):
        overlay = pygame.Surface((self.screen_width, self.game_area_height), pygame.SRCALPHA)
        overlay.fill((0, 0, 0, 120))
        screen.blit(overlay, (0, 0))
        
        pause_text = pygame.font.Font(None, 48).render("PAUSED", True, self.accent_color)
        pause_rect = pause_text.get_rect(center=(self.screen_width//2, self.game_area_height//2))
        screen.blit(pause_text, pause_rect)
    
    def draw_game_over_overlay(self, screen, final_score, stats_dict):
        overlay = pygame.Surface((self.screen_width, self.game_area_height), pygame.SRCALPHA)
        overlay.fill((0, 0, 0, 180))
        screen.blit(overlay, (0, 0))
        
        game_over_text = pygame.font.Font(None, 48).render("GAME OVER", True, self.warning_color)
        game_over_rect = game_over_text.get_rect(center=(self.screen_width//2, self.game_area_height//2))
        screen.blit(game_over_text, game_over_rect)
